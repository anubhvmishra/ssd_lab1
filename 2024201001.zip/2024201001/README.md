This is a readme file for the following shell scripts
2024201001_q1 and 2024201001_q2

Scripts can be run by doing ./2024201001_q1.sh and ./2024201001_q2.sh in bash.

For 2024201001_q1 we need to print lines containing POST and 404. Dot(.) is a special symbol for all characters and star(*) means zero or more times. Therefore it will match lines containing POST and 404 with any number of characters in between.

For 2024201001_q2 we will use awk to first separate words using comma (,) delimiter, now power levels are present at 4th position. So we get it using $4 and add it to variable j. At the end we print j using END. 
