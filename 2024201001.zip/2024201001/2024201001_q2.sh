#!/bin/bash
awk -F ',' '{j=j+$4} END {print j}' power_levels.txt
